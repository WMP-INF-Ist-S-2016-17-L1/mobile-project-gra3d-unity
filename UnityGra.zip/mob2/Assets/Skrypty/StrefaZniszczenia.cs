﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StrefaZniszczenia : MonoBehaviour {

	void Start () {}

	void Update () {}

	void OnTriggerEnter(Collider other){
		Destroy(other.gameObject);
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PauzaMenu : MonoBehaviour {

	public string levelToLoad;
	public bool paused = false;

	private Scene scene;

	void Start () {
		Time.timeScale=1;

		scene = SceneManager.GetActiveScene ();
	}

	void Update () {
		if (GUI.Button(new Rect(Screen.width/4+10, Screen.height/4+Screen.height/10+10, Screen.width/2-20, Screen.height/10), "paused")){
			paused = false;
		}

		if (Input.GetKeyDown(KeyCode.Escape) ){
			if (paused)
				paused = false;
			else
				paused = true;
		}

		if(paused)
			Time.timeScale = 0;
		else
			Time.timeScale = 1;
	}

	private void OnGUI()
	{
		if (paused){     
			GUI.Box(new Rect(Screen.width/4, Screen.height/4, Screen.width/2, Screen.height/2), "PAUSED");

			if (GUI.Button(new Rect(Screen.width/4+10, Screen.height/4+Screen.height/10+10, Screen.width/2-20, Screen.height/10), "RESUME")){
				paused = false;
			}

			if (GUI.Button(new Rect(Screen.width/4+10, Screen.height/4+2*Screen.height/10+10, Screen.width/2-20, Screen.height/10), "RESTART")){
				Application.LoadLevel (scene.name);// restart aplikacji
			}

			if (GUI.Button(new Rect(Screen.width/4+10, Screen.height/4+3*Screen.height/10+10, Screen.width/2-20, Screen.height/10), "QUIT")){
				// wyjście z aplikacji
			}
		}
	}

}
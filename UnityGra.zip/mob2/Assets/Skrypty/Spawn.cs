﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn : MonoBehaviour {
    public GameObject obstacle;
	public GameObject gold;

	float timeElapsed = 0;
    float spawnCycle = 1.5f;
    bool spawnGold = true;
	List<float> x = new List<float> { -1.5f, 0, 1.5f };

    void Start () {}

	void Update () {
        timeElapsed += Time.deltaTime;
        if (timeElapsed > spawnCycle)
        {
            GameObject temp;

			if (spawnGold) {
				temp = (GameObject)Instantiate (gold);
				Vector3 pos = temp.transform.position;
				temp.transform.position = new Vector3 (x [Random.Range (0, 3)], pos.y, pos.z);
			} else {
				temp = (GameObject)Instantiate (obstacle);
				Vector3 pos = temp.transform.position;
				temp.transform.position = new Vector3 (x [Random.Range (0, 3)], pos.y, pos.z);
			}

            timeElapsed -= spawnCycle;
            spawnGold = !spawnGold;
        }
    }
}

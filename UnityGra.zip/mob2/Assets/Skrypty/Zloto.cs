﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zloto : MonoBehaviour {
	public float objectSpeed = -0.3f;

	void Start () {}

	void Update () {
		if (Time.timeScale == 1) {
			transform.Translate (0, objectSpeed, 0);
		}
	}
}

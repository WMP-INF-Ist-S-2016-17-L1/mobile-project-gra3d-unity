﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ruchGracza : MonoBehaviour {

	public KontrolaGry control;

	public float horizVel = 0;
	public int laneNum = 2;
	public string controlLocked = "n";

	private float screenCenterX;

	void Start () {
		screenCenterX = Screen.width * 0.5f;
	}

	void Update () {
		GetComponent<Rigidbody>().velocity = new Vector3 (horizVel, 0, 0);

		if(Input.touchCount > 0){
			Touch firstTouch = Input.GetTouch(0);

			if(firstTouch.phase == TouchPhase.Began)
			{
				if(firstTouch.position.x < screenCenterX && (laneNum>1) && (controlLocked == "n"))
				{
					horizVel = -1.5f;
					StartCoroutine (stopSlide());
					laneNum -= 1;
					controlLocked = "y";
				}
				else if(firstTouch.position.x > screenCenterX && (laneNum<3) && (controlLocked == "n"))
				{
					horizVel = 1.5f;
					StartCoroutine (stopSlide());
					laneNum += 1;
					controlLocked = "y";
				}
			}
		}

    }

	IEnumerator stopSlide(){
		yield return new WaitForSeconds (1.0f);
		horizVel = 0;
		controlLocked = "n";
	}

    void OnTriggerEnter(Collider other)
    {
		if(other.gameObject.name == "Zloto(Clone)")
		{
			control.GoldCollected ();
		}
		else if(other.gameObject.name == "Przeszkoda(Clone)")
		{
			control.ObstacleCollected ();
		} 
		Destroy(other.gameObject);
    }

}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Przeszkoda : MonoBehaviour {
    public float objectSpeed = -0.3f;

    void Start () {}

	void Update () {
		if (Time.timeScale == 1) {
			transform.Translate (0, 0, objectSpeed);
		}
    }
}
